namespace WiredTwilightBackend;

using WiredTwilightBackend;
public class UpdateUsernameRequest
{
    public string? NewUsername { get; set; }
}